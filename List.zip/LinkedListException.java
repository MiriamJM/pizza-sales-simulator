import java.lang.RuntimeException;

/**
 * Write a description of class LinkedListException here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LinkedListException extends RuntimeException
{
    
}
