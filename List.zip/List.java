
public class List
{
    private Node _head;
    
    
    public void insert(Object object, int index)
    {
        Node node = new Node(object);
        
        if(_head == null)
        {
            if(index != 0) throw new LinkedListException();
            
            _head = node;            
        }
        else if(index == 0)
        {
            _head.setNext(node);
            _head = node;
        }
        // We have more than one item.
        // We need to find the node after which we insert our new node.
        else
        {
            int currentIndex = 0;
            Node current = _head;
            while(current != null)
            {
                if(currentIndex == index - 1)
                {
                    node.setNext(current.getNext());
                    current.setNext(node);
                    
                    return;
                }
                
                current = current.getNext();
                ++currentIndex;
            }
            
            // index >= size
            throw new LinkedListException();
        }
    }
    
    public Object remove(int index)
    {        
        if(index == 0 && _head != null)
        {
            Object removedObject = _head.getData();
            _head = _head.getNext();
            return removedObject;
        }
        else
        {
            int currentIndex = 0;
            Node current = _head;
            while(current != null)
            {
                if(currentIndex == index - 1)
                {
                    Node removedNode = current.getNext();
                    current.setNext(removedNode.getNext());
                    return removedNode.getData();
                }
                
                current = current.getNext();
                ++currentIndex;
            }
        }
        
        // index >= size
        throw new LinkedListException();
    }
    
    public void append(Object object)
    {
        Node tail = getTail();
        Node node = new Node(object);
        
        if(tail == null)
        {
            _head = node;
        }
        else
        {
            tail.setNext(node);
        }
    }
    
    public void delete(int index)
    {
        remove(index);
    }
    
    public int size()
    {
        int size = 0;
        Node current = _head;
        while(current != null)
        {
           current = current.getNext();
           ++size;
        }
        return size;
    }
    
    public String toString()
    {
        String result = "";
        
        Node current = _head;
        while(current != null)
        {
           result += current.getData().toString();
           current = current.getNext();
           if(current != null)
           {
               result += ", ";
           }
        }
        
        return result;
    }
    
    public boolean isEmpty()
    {
        return size() == 0;
    }
    
    public int indexOf(Object object)
    {
        int index = -1;
        
        int currentIndex = 0;
        Node current = _head;
        while(current != null && index == -1)
        {
            if(current.getData() == object)
            {
                index = currentIndex;
            }
            
            current = current.getNext();
            ++currentIndex;
        }
        
        return index;
    }
    
    private Node getTail()
    {
        Node tail = _head;
        while(tail != null && tail.getNext() != null)
        {
           tail = tail.getNext();
        }
        return tail;
    }
    
    public class Node
    {
        private Node _next;
        private Object _data;
        
        public Node(Object data)
        {
            _data = data;
        }
        
        public Node getNext()
        {
            return _next;
        }
        
        public void setNext(Node next)
        {
            _next = next;
        }
        
        public Object getData()
        {
            return _data;
        }
    }
}
