/**
 * This class will be used to decorate Pizza Objects.  
 * @author Miriam Mnyuku
 */
public class Pepperoni extends Meat
{
	/**
	 * Constructor sets the description, cost to $3.75 and 330 calories
	 */
	public Pepperoni()
	{
		super("Pepperoni", new Money(3,75), 330);
	}

}