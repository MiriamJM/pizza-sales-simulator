
/**
 * This class will be used to decorate Pizza Objects.  
 * @author Miriam Mnyuku
 * 
 */
public class Alfredo extends Base
{

	/**
	 * Constructor sets the description, cost to $2.55 and 365 calories
	 */
	public Alfredo()
	{
		super("Alfredo", new Money(2,55), 365);
	}
}

    
